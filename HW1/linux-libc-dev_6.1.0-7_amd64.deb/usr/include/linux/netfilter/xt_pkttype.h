/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _XT_PKTTYPE_H
#define _XT_PKTTYPE_H

struct xt_pkttype_info {
	int	pkttype;
	int	invert;
};
#endif /*_XT_PKTTYPE_H*/
